<?php
    class APIMethods{
        private $pdo;
        private $_key, $_iv;
        private $_skey, $_siv;
        public function __construct(){
            try{
                $host="localhost"; $uname="badgesaesajce_root"; $pword="}E+3_N=CdvnE"; $db="badgesaesajce_db";
                $this->pdo = new PDO("mysql:host=$host;dbname=$db",$uname,$pword);
                $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                if (session_status() == PHP_SESSION_NONE && !isset($_SESSION)) {
                    session_start(); 
                }
                if(!$this->_key || !$this->_iv){
                    $this->_key = $_SESSION['ENC_KEY'] ?? $_SESSION['ENC_KEY'] = SHA1(time());
                    $this->_iv = substr(SHA1($this->_key),-16);
                    $this->_skey = SHA1("pay.aesajce.in");
                    $this->_siv = substr(SHA1($this->_skey),-16);
                }
            } catch (PDOException $e) {
                echo 'connection failed: '.$e->getMessage();
            }
        }
        function enc($_value, $_static = false){
            return base64_encode(openssl_encrypt($_value, "AES-256-CBC", ($_static ? $this->_skey : $this->_key), 0, ($_static ? $this->_siv : $this->_iv)));
        } 
        function dec($_value, $_static = false){
            return openssl_decrypt(base64_decode($_value), "AES-256-CBC", ($_static ? $this->_skey : $this->_key), 0, ($_static ? $this->_siv : $this->_iv));
        }
        function authUser(){
            return isset($_SESSION['auth_user'])?$_SESSION['auth_user']:array("status"=>false);
        }
        function setAuthUser($_params){
            $_SESSION['auth_user'] = $_params;
        }
        function isAuthUser($_params){
            if(isset($_params['aeslink'])){
                $__vals = explode("#",$_params['aeslink']);
                $_params['staff_code'] = openssl_decrypt(base64_decode($__vals[1]), "AES-256-CBC", $__vals[0], 0, substr(SHA1($__vals[0]),-16));
            }
            $this->setAuthUser($_POST);
            return true;
        }


        
        //student Functions

        public function storeStudentDetails($data)
        {
            try {
                // Get authenticated user
                $authUser = $this->authUser();
                if (!$authUser || !$authUser['status']) {
                    throw new Exception("User not authenticated");
                }

                // Create uploads directory if it doesn't exist
                $targetDir = $_SERVER['DOCUMENT_ROOT'] . "/public/uploads/";
                if (!file_exists($targetDir)) {
                    mkdir($targetDir, 0777, true);
                }

                // Generate unique filename to prevent overwrites
                $fileExtension = strtolower(pathinfo($_FILES["certification_file"]["name"], PATHINFO_EXTENSION));
                $uniqueFilename = uniqid() . '_' . time() . '.' . $fileExtension;
                $targetFile = $targetDir . $uniqueFilename;

                // Validate file upload
                if (!move_uploaded_file($_FILES["certification_file"]["tmp_name"], $targetFile)) {
                    throw new Exception("Failed to upload file");
                }

                $stmt = $this->pdo->prepare("
                    INSERT INTO badges_certificate_list (
                        student_id,
                        certification_title,
                        certification_file, 
                        certification_desc, 
                        start_date, 
                        end_date, 
                        certification_mode,
                        status
                    ) 
                    VALUES (
                        :student_id,
                        :certification_title,
                        :certification_file, 
                        :certification_desc, 
                        :start_date, 
                        :end_date, 
                        :certification_mode,
                        :status
                    )
                ");

                $params = [
                    ':student_id' => $authUser['admission_no'],
                    ':certification_title' => $data['certification_title'],
                    ':certification_desc' => $data['certification_desc'],
                    ':start_date' => $data['start_date'],
                    ':end_date' => $data['end_date'],
                    ':certification_mode' => $data['certification_mode'],
                    ':certification_file' => '/public/uploads/' . $uniqueFilename,
                    ':status' => $data['status']
                ];

                $stmt->execute($params);

                if ($stmt->rowCount() > 0) {
                    return ["status" => true, "message" => "Certificate uploaded successfully"];
                } else {
                    throw new Exception("Failed to insert record into database");
                }

            } catch (Exception $e) {
                // If there was an error and we uploaded a file, remove it
                if (isset($targetFile) && file_exists($targetFile)) {
                    unlink($targetFile);
                }
                return ["status" => false, "message" => $e->getMessage()];
            }
        }

        public function getTeacherCertificates($data) {
            try {
                $query = "
                    SELECT *
                    FROM badges_certificate_list
                    WHERE 1=1
                ";
                
                $params = [];
                
                if (!empty($data['status'])) {
                    $query .= " AND status = :status";
                    $params[':status'] = $data['status'];
                }
                
                if (!empty($data['search'])) {
                    $query .= " AND certification_title LIKE :search";
                    $params[':search'] = "%{$data['search']}%";
                }
                
                $query .= " ORDER BY created_at DESC";
                
                $stmt = $this->pdo->prepare($query);
                $stmt->execute($params);
                
                return array(
                    "status" => true,
                    "data" => $stmt->fetchAll(PDO::FETCH_ASSOC)
                );
            } catch (Exception $e) {
                return array(
                    "status" => false,
                    "message" => $e->getMessage()
                );
            }
        }
        
        public function getCertificateDetails($data) {
            try {
                $stmt = $this->pdo->prepare("
                    SELECT *
                    FROM badges_certificate_list
                    WHERE certificate_id = :cert_id
                ");
                
                $stmt->execute([':cert_id' => $data['cert_id']]);
                $cert = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$cert) {
                    throw new Exception("Certificate not found");
                }
                
                return array(
                    "status" => true,
                    "data" => $cert
                );
            } catch (Exception $e) {
                return array(
                    "status" => false,
                    "message" => $e->getMessage()
                );
            }
        }
        
        public function updateStatus($data) {
            try {
                // Log incoming data
                error_log('Updating status with data: ' . print_r($data, true));

                // Validate inputs
                if (empty($data['certificate_id'])) {
                    throw new Exception('Certificate ID is required');
                }
                if (empty($data['status_action'])) {
                    throw new Exception('Status action is required');
                }
                if (empty($data['teacher_comment'])) {
                    throw new Exception('Comment is required');
                }

                // Convert action to status
                switch ($data['status_action']) {
    case 'approve':
        $newStatus = 'approved';
        break;
    case 'reject':
        $newStatus = 'rejected';
        break;
    case 'revert':
        $newStatus = 'reverted';
        break;
    default:
        throw new Exception('Invalid status action');
}


                // Begin transaction
                $this->pdo->beginTransaction();

                try {
                    // Update the certificate status - removed updated_at field
                    $stmt = $this->pdo->prepare("
                        UPDATE badges_certificate_list 
                        SET 
                            status = ?,
                            teacher_comment = ?
                        WHERE certificate_id = ?
                    ");

                    $success = $stmt->execute([
                        $newStatus,
                        trim($data['teacher_comment']),
                        intval($data['certificate_id'])
                    ]);

                    if (!$success) {
                        throw new Exception('Failed to update database');
                    }

                    if ($stmt->rowCount() === 0) {
                        throw new Exception('Certificate not found or no changes made');
                    }

                    // Commit the transaction
                    $this->pdo->commit();

                    // Log success
                    error_log('Successfully updated certificate status');

                    return [
                        'status' => true,
                        'message' => 'Certificate status updated successfully'
                    ];

                } catch (Exception $e) {
                    // Rollback on error
                    $this->pdo->rollBack();
                    throw $e;
                }

            } catch (Exception $e) {
                error_log('Error updating status: ' . $e->getMessage());
                return [
                    'status' => false,
                    'message' => $e->getMessage()
                ];
            }
        }
        
      //Admin functions
    public function createBadgeCategory($data)
    {
            try {
                // Setup for badge icon upload
                $targetDir = $_SERVER['DOCUMENT_ROOT'] . "/public/uploads/badges/";
                if (!file_exists($targetDir)) {
                    mkdir($targetDir, 0777, true);
                }
                
                // Process badge icon if provided
                $imagePath = null;
                if (isset($_FILES['badge_icon']) && $_FILES['badge_icon']['error'] !== UPLOAD_ERR_NO_FILE) {
                    if ($_FILES['badge_icon']['error'] !== UPLOAD_ERR_OK) {
                        error_log("Upload error code: " . $_FILES['badge_icon']['error']);
                        throw new Exception("File upload error: " . $this->getUploadErrorMessage($_FILES['badge_icon']['error']));
                    }
        
                    try {
                        $imagePath = $this->handleImageUpload($_FILES['badge_icon']);
                    } catch (Exception $e) {
                        error_log("Image upload error details: " . $e->getMessage());
                        throw $e;
                    }
                }
                
                // First check if the badge category already exists
                $checkStmt = $this->pdo->prepare("
                    SELECT badge_id FROM tbl_badge_categories 
                    WHERE badge_name = :badge_name
                ");
                $checkStmt->execute([':badge_name' => $data['badge_name']]);
                
                if ($checkStmt->rowCount() > 0) {
                    throw new Exception("Badge category with this name already exists");
                }
                
                // Start a transaction
                $this->pdo->beginTransaction();
                
                // Insert the new badge category
                $stmt = $this->pdo->prepare("
                    INSERT INTO tbl_badge_categories (
                        badge_name,
                        badge_description,
                        badge_icon,
                        badge_status
                    ) 
                    VALUES (
                        :badge_name,
                        :description,
                        :badge_icon,
                        :status
                    )
                ");
                
                $params = [
                    ':badge_name' => $data['badge_name'],
                    ':description' => $data['badge_description'],
                    ':badge_icon' => $imagePath,
                    ':status' => $data['badge_status'] ?? '0'
                ];
                
                $stmt->execute($params);
                
                $badgeId = null;
                if ($stmt->rowCount() > 0) {
                    $badgeId = $this->pdo->lastInsertId();
                    
                    // If this badge was created from a request, update the request with the badge ID
                    if (isset($data['from_request_id']) && !empty($data['from_request_id'])) {
                        $requestId = $data['from_request_id'];
                        
                        // Update the badge request to link it to the created badge
                        $updateStmt = $this->pdo->prepare("
                            UPDATE tbl_badge_requests
                            SET created_badge_id = :badge_id
                            WHERE id = :request_id AND status = 'approved'
                        ");
                        
                        $updateStmt->execute([
                            ':badge_id' => $badgeId,
                            ':request_id' => $requestId
                        ]);
                        
                        // If no rows were affected, the request might not exist or not be approved
                        if ($updateStmt->rowCount() === 0) {
                            error_log("Warning: Could not update badge request ID $requestId with badge ID $badgeId");
                        }
                    }
                    
                    // Commit the transaction
                    $this->pdo->commit();
                    
                    return [
                        "status" => true, 
                        "message" => "Badge category created successfully", 
                        "badge_id" => $badgeId
                    ];
                } else {
                    // Rollback if no badge was created
                    $this->pdo->rollBack();
                    throw new Exception("Failed to create badge category");
                }
                
            } catch (Exception $e) {
                // Rollback on error
                if ($this->pdo->inTransaction()) {
                    $this->pdo->rollBack();
                }
                
                error_log($e);
                // If there was an error and we uploaded a file, remove it
                if (isset($targetFile) && file_exists($targetFile)) {
                    unlink($targetFile);
                }
                return ["status" => false, "message" => $e->getMessage()];
            }
    }
    private function handleImageUpload($file)
    {
        $targetDir = $_SERVER['DOCUMENT_ROOT'] . "/public/uploads/badges/";
    
        // Generate a unique file name
        $fileExt = pathinfo($file['name'], PATHINFO_EXTENSION);
        $uniqueName = uniqid('badge_', true) . '.' . strtolower($fileExt);
    
        $targetFile = $targetDir . $uniqueName;
    
        // Validate file type (optional but recommended)
        $allowedTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        if (!in_array(strtolower($fileExt), $allowedTypes)) {
            throw new Exception("Unsupported file type. Allowed types: " . implode(", ", $allowedTypes));
        }
    
        // Validate file size (optional)
        if ($file['size'] > 2 * 1024 * 1024) { // 2MB limit
            throw new Exception("File size exceeds 2MB limit.");
        }
    
        // Move uploaded file
        if (!move_uploaded_file($file['tmp_name'], $targetFile)) {
            throw new Exception("Failed to move uploaded file.");
        }
    
        // Return relative path to save in DB
        return "/public/uploads/badges/" . $uniqueName;
    }
    public function getBadgeCategories()
    {
        error_log("hi");
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM tbl_badge_categories ORDER BY badge_id DESC");
            $stmt->execute();
            $badges = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("Fetched " . count($badges) . " badge categories.");
    
            return [
                "status" => true,
                "badges" => $badges
            ];
        } catch (Exception $e) {
            return [
                "status" => false,
                "message" => "Failed to fetch badge categories: " . $e->getMessage()
            ];
        }
    }

    public function createBadgeRequest($data) {
        try {
            $authUser = $this->authUser();
            if (!$authUser || !$authUser['status']) {
                throw new Exception("User not authenticated");
            }

            $stmt = $this->pdo->prepare("
                INSERT INTO tbl_badge_requests (
                    badge_name,
                    badge_description,
                    primary_color,
                    secondary_color,
                    badge_shape,
                    badge_icon,
                    requested_by,
                    status
                ) VALUES (
                    :badge_name,
                    :description,
                    :primary_color,
                    :secondary_color,
                    :shape,
                    :icon,
                    :user_id,
                    'pending'
                )
            ");

            $params = [
                ':badge_name' => $data['badge_name'],
                ':description' => $data['badge_description'],
                ':primary_color' => $data['primary_color'],
                ':secondary_color' => $data['secondary_color'],
                ':shape' => $data['badge_shape'],
                ':icon' => $data['badge_icon'],
                ':user_id' => $authUser['staff_code']
            ];

            $stmt->execute($params);

            return [
                "status" => true,
                "message" => "Badge request submitted successfully"
            ];

        } catch (Exception $e) {
            return ["status" => false, "message" => $e->getMessage()];
        }
    }
    public function getBadgeRequests()
    {
        error_log("hi");
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM tbl_badge_requests WHERE status = 'pending' ORDER BY created_at DESC");
            $stmt->execute();
            $badges = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("Fetched " . count($badges) . " badge categories.");
    
            return [
                "status" => true,
                "badges" => $badges
            ];
        } catch (Exception $e) {
            return [
                "status" => false,
                "message" => "Failed to fetch badge categories: " . $e->getMessage()
            ];
        }
    }
    public function updateBadgeRequestStatus($data) {
        try {
            // Validate the required fields
            if (!isset($data['id']) || !isset($data['status'])) {
                throw new Exception("Badge ID and status are required");
            }
            
            // Validate the status value
            $allowedStatuses = ['approved', 'rejected'];
            if (!in_array($data['status'], $allowedStatuses)) {
                throw new Exception("Invalid status value");
            }
            
            // Update the badge request status
            $stmt = $this->pdo->prepare("
                UPDATE tbl_badge_requests 
                SET status = :status, 
                    updated_at = NOW() 
                WHERE request_id = :id
            ");
            
            $params = [
                ':id' => $data['id'],
                ':status' => $data['status']
            ];
            
            $stmt->execute($params);
            
            // Check if any row was affected
            if ($stmt->rowCount() === 0) {
                throw new Exception("Badge request not found or no changes made");
            }
            
            // If approved, get the badge request details to return them
            if ($data['status'] === 'approved') {
                $stmt = $this->pdo->prepare("
                    SELECT * FROM tbl_badge_requests 
                    WHERE request_id = :id
                ");
                $stmt->execute([':id' => $data['id']]);
                $badgeRequest = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($badgeRequest) {
                    return [
                        "status" => true,
                        "message" => "Badge request approved successfully",
                        "badge_request" => $badgeRequest
                    ];
                }
            }
            
            return [
                "status" => true,
                "message" => $data['status'] === 'approved' 
                    ? "Badge request approved successfully" 
                    : "Badge request rejected successfully"
            ];
        } catch (Exception $e) {
            return ["status" => false, "message" => $e->getMessage()];
        }
    }
}
?>